"Credit Card Default prediction using Logistics Regression and Random Forest models" 
                            

                                  #LOGISTICS REGRESSION MODEL
# Installing packages
install.packages("DataExplorer")
install.packages("dplyr")
install.packages("caret")
install.packages("e1071")

#Importing libraries
library(DataExplorer)
library (dplyr)
library(ggplot2)

#Setting the working directory to dataset location
setwd("/Users/mac/Desktop/DMMLProjectcode")
creditCardData <- read.csv("creditCard.csv")
head(creditCardData)

#Setting the header
colnames(creditCardData) <- as.character(unlist(creditCardData[1,]))
creditCardData <- creditCardData[-1, ]
head(creditCardData)

#Renaming the dependent variable to be without space
colnames(creditCardData)[colnames(creditCardData)=="default payment next month"] <- "default_payment"
head(creditCardData)

#Exploratory Data Analysis
dim(creditCardData) #checking the data dimensions
str(creditCardData) #shows the structure of the dataset
View(creditCardData)

creditCardData[, 1:25] <- sapply(creditCardData[, 1:25], as.character)
creditCardData[, 1:25] <- sapply(creditCardData[, 1:25], as.numeric)
creditCardData$default_payment <- as.factor(creditCardData$default_payment)
str(creditCardData)

summary(creditCardData) #computes some basic descriptive information of the dataset

#Checking for any NA value 
sapply(creditCardData,function(x) sum(is.na(x)))
dim(creditCardData)
'As we can see, there are no missing values in the dataframe. So the data does not need cleaning'

table(creditCardData$EDUCATION)
"Since Education variable is categorical as Education (1 = graduate school; 2 = university; 3 = high school; 4 = others)
the table() above shows us that 0, 5 and 6 are not in any category therefore we can classify them into 4 = others since we don’t have any further details about them"

creditCardData$EDUCATION[creditCardData$EDUCATION == 0] <- 4
creditCardData$EDUCATION[creditCardData$EDUCATION == 5] <- 4
creditCardData$EDUCATION[creditCardData$EDUCATION == 6] <- 4

table(creditCardData$EDUCATION) # checking again

table(creditCardData$MARRIAGE)
"Since Marriage variable is categorical as Marital status (1 = married; 2 = single; 3 = others)
the table() above shows us that 0 is not in any category therefore we can classify them into 3 = others since we don’t have any further details about it"

creditCardData$MARRIAGE[creditCardData$MARRIAGE == 0] <- 3

table(creditCardData$MARRIAGE) # checking again

#multi-variate analysis of the variables
plot_correlation(na.omit(creditCardData), maxcat = 8L)
"From the heat map, we can see weak correlation of AGE, BILL_AMT1, BILL_AMT2, BILL_AMT3, BILL_AMT4, BILL_AMT5, BILL_AMT6 with our target variable default_payment"

#univariate analysis of the variables
plot_histogram(creditCardData)

#Feature Engineering
#deleting the variables which have significantly low correlation values
newCreditCard <- select(creditCardData, -one_of('ID','AGE', 'BILL_AMT2',
                                 'BILL_AMT3','BILL_AMT4','BILL_AMT5','BILL_AMT6'))

head(newCreditCard)

#Pre-processing
#Performing Standardization on the data (making the mean zero and the standard deviation one)
newCreditCard[, 1:17] <- scale(newCreditCard[, 1:17])
head(newCreditCard)
str(newCreditCard)

#Spliting the data into Testing and Training
"30% for testing and 70% for training" 
#seed 450
set.seed (450)
newData <- sort(sample(nrow(newCreditCard), nrow(newCreditCard)*0.7))

#Training data
train <- newCreditCard[newData,]

#Testing data
test <- newCreditCard[-newData,]

dim(train)
dim(test)

#Model Development (Logistic regression model)
##fit a logistic regression model with the training dataset
#logReg.model <- glm(default_payment ~., data = train, family = binomial(link = "logit"))
logReg.model <- glm(default_payment ~., data = train, family = binomial)
summary(logReg.model)

##Prediction on testing dataset
test[1:10,]

logReg.pred <- predict(logReg.model, test, type="response")
head(logReg.pred, 50)

"Assign the labels using decision rule
if the prediction is > 0.5, assign it 1 else 0"
newlogRegPred <- ifelse(logReg.pred > 0.5, 1, 0)
head(newlogRegPred, 50)


#Evaluation
"Confusion Matrix for Logistic Regression"
library(caret)
library(e1071)
logReg.cm <-table(newlogRegPred, test[,18])
confusionMatrix(logReg.cm)

"ROC curve for Logistic Regression"
#install.packages("ROCR")
library(ROCR)
logReg.predition <- prediction(logReg.pred, test$default_payment)
logReg.performance <- performance(logReg.predition, "tpr","fpr")

#Creating a DF for the True postive(TP) and False positive(FP) rates for Logistics Regression
tpfp <- data.frame(FP = logReg.performance@x.values[[1]], TP = logReg.performance@y.values[[1]])

g <- ggplot() + 
  geom_line(data = tpfp, aes(x = FP, y = TP, color = 'Logistic Regression')) + 
  geom_segment(aes(x = 0, xend = 1, y = 0, yend = 1)) +
  ggtitle('ROC Curve') + 
  labs(x = 'False Positive Rate', y = 'True Positive Rate') 

g +  scale_colour_manual(name = 'Classifier', values = c('Logistic Regression'='#FF0000') )

"AUC curve for Logistic Regression"
aucLogReg <- performance(logReg.predition, measure = "auc")
aucLogReg <- aucLogReg@y.values[[1]]
aucLogReg


                                        #RANDOM FOREST MODEL
##Using the Testing and Training datasets from Logistics Regression
library (randomForest)
library (gbm)
library (ipred)

rainF.model  <- randomForest ( train$default_payment ~., data  = train)
summary(rainF.model)
varImpPlot(rainF.model)

#Confusion matrix for Random Forest
rainF.cm  <- (predict(rainF.model , newdata = test))
confusionMatrix(test$default_payment, rainF.cm, positive = "0")

"ROC curve for Random Forest"
#Creating a DF for the True postive(TP) and False positive(FP) rates  for Rain Forest Model
#install.packages("rpart")
library(rpart)
tree2.pred.prob <- predict(rainF.model, newdata = test, type = 'prob')

rainF.prediction <- prediction(tree2.pred.prob[,2], test$default_payment)
rainF.performance <- performance(rainF.prediction, "tpr", "fpr")
tpfp2 <- data.frame(FP = rainF.performance@x.values[[1]], TP = rainF.performance@y.values[[1]])

g <- ggplot() + 
  geom_line(data = tpfp2, aes(x = FP, y = TP, color = 'Random Forest')) + 
  geom_segment(aes(x = 0, xend = 1, y = 0, yend = 1)) +
  ggtitle('ROC Curve') + 
  labs(x = 'False Positive Rate', y = 'True Positive Rate') 

g +  scale_colour_manual(name = 'Classifier', values = c('Random Forest'='#0000EA'))


"AUC curve for Random Forest"
aucRainF <- performance(rainF.prediction, measure = "auc")
aucRainF <- aucRainF@y.values[[1]]
aucRainF

#Merging ROR curves of Logistic Regression and Random Forest
g <- ggplot() + 
  geom_line(data = tpfp, aes(x = FP, y = TP, color = 'Logistic Regression')) +
  geom_line(data = tpfp2, aes(x = FP, y = TP, color = 'Random Forest')) + 
  geom_segment(aes(x = 0, xend = 1, y = 0, yend = 1)) +
  ggtitle('ROC Curve') + 
  labs(x = 'False Positive Rate', y = 'True Positive Rate') 

g +  scale_colour_manual(name = 'Classifier', values = c('Logistic Regression'='#960200','Random Forest'='#0000EA') )


