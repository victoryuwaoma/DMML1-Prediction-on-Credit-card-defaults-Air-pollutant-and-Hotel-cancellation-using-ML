"Regression analysis on Air pollutant using Multiple Regression"

                                #MULTIPLE REGRESSION MODEL
#Importing libraries
install.packages("car")

library(car)
library(ggplot2)
library(dplyr)
library(MASS)
library(DataExplorer)


#Setting the working directory to dataset location
setwd("/Users/mac/Desktop/DMMLProjectcode")
airPollutionData <- read.csv("airpollutionTiantan.csv")
head(airPollutionData)

#Exploratory Data Analysis
dim(airPollutionData) #checking the data dimensions
str(airPollutionData) #shows the structure of the dataset
View(airPollutionData)
summary(airPollutionData) #computes some basic descriptive information of the dataset

#Checking for any NA value 
is.na(airPollutionData)
sapply(airPollutionData,function(x) sum(is.na(x)))
'As we can see, there are missing values in some variables. So the data need cleaning some form of cleaning'

#Dropping all the NA values
airPollutionData <- airPollutionData[!is.na(airPollutionData$PM2.5), ]
airPollutionData <- airPollutionData[!is.na(airPollutionData$PM10), ]
airPollutionData <- airPollutionData[!is.na(airPollutionData$SO2), ]
airPollutionData <- airPollutionData[!is.na(airPollutionData$NO2), ]
airPollutionData <- airPollutionData[!is.na(airPollutionData$CO), ]
airPollutionData <- airPollutionData[!is.na(airPollutionData$O3), ]
airPollutionData <- airPollutionData[!is.na(airPollutionData$TEMP), ]
airPollutionData <- airPollutionData[!is.na(airPollutionData$PRES), ]
airPollutionData <- airPollutionData[!is.na(airPollutionData$DEWP), ]
airPollutionData <- airPollutionData[!is.na(airPollutionData$RAIN), ]
airPollutionData <- airPollutionData[!is.na(airPollutionData$wd), ]
airPollutionData <- airPollutionData[!is.na(airPollutionData$WSPM), ]

sapply(airPollutionData,function(x) sum(is.na(x))) #checking again
dim(airPollutionData)

#Criteria to satisfy before Multiple regression
#Checking for correlation between the dependent and independent variables using Correlation matrix
cor(airPollutionData[c("PM2.5","NO2","CO","TEMP","PRES","DEWP","RAIN","WSPM")])

#Visualizing the data using Histogram
ggplot(airPollutionData, aes(x = year)) + geom_histogram() + ggtitle('Year of data')
ggplot(airPollutionData, aes(x= month)) + geom_histogram() + ggtitle('Month of data')
ggplot(airPollutionData, aes(x= day)) + geom_histogram() + ggtitle('Day of data')
ggplot(airPollutionData, aes(x= hour)) + geom_histogram() + ggtitle('Hour of data')
ggplot(airPollutionData, aes(x= PM2.5)) + geom_histogram() + ggtitle('PM2.5 Concentration (ug/m^3)')
ggplot(airPollutionData, aes(x= NO2)) + geom_histogram() + ggtitle('NO2 Concentration (ug/m^3)')
ggplot(airPollutionData, aes(x = CO)) + geom_histogram() + ggtitle('CO Concentration (ug/m^3)')
ggplot(airPollutionData, aes(x = TEMP)) + geom_histogram() + ggtitle('Temperature (degree Celsius)')
ggplot(airPollutionData, aes(x = PRES)) + geom_histogram() + ggtitle('Pressure (hPa)')
ggplot(airPollutionData, aes(x = DEWP)) + geom_histogram() + ggtitle('Dew point temperature (degree Celsius)')
ggplot(airPollutionData, aes(x = RAIN)) + geom_histogram() + ggtitle('Precipitation (mm)')
ggplot(airPollutionData, aes(x = WSPM)) + geom_histogram() + ggtitle('Wind speed (m/s)')

                              #MULTIPLE REGRESSION MODEL
library(caret)
#Spliting the data into Testing and Training
"30% for testing and 70% for training" 
#seed 302
set.seed (302)
newAirData = sort(sample(nrow(airPollutionData), nrow(airPollutionData)*0.7))

#Training data
train <- airPollutionData[newAirData,]

#Testing data
test <- airPollutionData[-newAirData,]

dim(train)
dim(test)

#Plots between the 5 Independent variables and the dependent variable (PM2.5)
coplot(airPollutionData$PM2.5 ~ airPollutionData$TEMP | airPollutionData$PRES | airPollutionData$DEWP | airPollutionData$RAIN | airPollutionData$WSPM, panel= panel.smooth)

#Plots between the 5 Independent variables and the dependent variable (NO2)
coplot(airPollutionData$NO2 ~ airPollutionData$TEMP | airPollutionData$PRES | airPollutionData$DEWP | airPollutionData$RAIN | airPollutionData$WSPM, panel= panel.smooth)

#Plots between the 5 Independent variables and the dependent variable (CO)
coplot(airPollutionData$CO ~ airPollutionData$TEMP | airPollutionData$PRES | airPollutionData$DEWP | airPollutionData$RAIN | airPollutionData$WSPM, panel= panel.smooth)

#install.packages("psych")
library(psych)
pairs.panels(airPollutionData[6:17])


#Model Development
## fit a Multiple regression model with the training dataset 
#Using PM2.5 as dependent variable
multiR.model1 <- lm(PM2.5 ~ TEMP + PRES + DEWP + RAIN + WSPM, data = train)
multiR.model1
summary(multiR.model1)
plot(multiR.model1)

multiR.pred1 <- predict(multiR.model1, test)
summary(multiR.pred1)
plot(test$PM2.5, multiR.pred1)

#RMSE for PM2.5
pm25.rmse <- sqrt(sum((multiR.pred1 - test$PM2.5)^2)/length(test$PM2.5))
c(RMSE = pm25.rmse, R2=summary(multiR.model1)$r.squared)

#Checking for multicollinearity
vif(multiR.model1)

#Using NO2 as dependent variable
multiR.model2 <- lm(NO2 ~ TEMP + PRES + DEWP + RAIN + WSPM, data = train)
multiR.model2
summary(multiR.model2)
plot(multiR.model2)

multiR.pred2 <- predict(multiR.model2, test)
summary(multiR.pred2)
plot(test$NO2, multiR.pred2)

#RMSE for NO2
no2.rmse <- sqrt(sum((multiR.pred1 - test$NO2)^2)/length(test$NO2))
c(RMSE = no2.rmse, R2=summary(multiR.model1)$r.squared)

#Checking for multicollinearity
vif(multiR.model2)



#Using CO as dependent variable
multiR.model3 <- lm(CO ~ TEMP + PRES + DEWP + RAIN + WSPM, data = train)
multiR.model3
summary(multiR.model3)
plot(multiR.model3)

multiR.pred3 <- predict(multiR.model3, test)
summary(multiR.pred3)
plot(test$CO, multiR.pred3)

#RMSE for CO
co.rmse <- sqrt(sum((multiR.pred1 - test$CO)^2)/length(test$CO))
c(RMSE = co.rmse, R2=summary(multiR.model1)$r.squared)

#Checking for multicollinearity
vif(multiR.model3)

#Comparing Models
anova(multiR.model1)
anova(multiR.model2)
anova(multiR.model3)




