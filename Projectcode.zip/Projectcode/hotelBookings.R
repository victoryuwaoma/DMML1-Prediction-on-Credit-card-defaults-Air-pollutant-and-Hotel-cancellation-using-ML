"Hotel booking prediction using k-Nearest Neighbor (kNN) and Support vector machine (SVM)"

                                    #K NEAREST NEIGHBOR
# Importing libraries
install.packages("caret")
library(caret)
library(DataExplorer)
library (dplyr)

setwd("/Users/mac/Desktop/DMMLProjectcode")
hotelData <- read.csv("hotelBookings.csv")
head(hotelData)
View(hotelData)

#Exploratory Data Analysis
dim(hotelData) #checking the data dimensions
str(hotelData) #shows the structure of the dataset

hotelData[, 1:32] <- sapply(hotelData[, 1:32], as.numeric)
str(hotelData)

#Normalization
normalize <- function(x) {
  return ((x - min(x)) / (max(x) - min(x))) }

hotelDataN <- as.data.frame(lapply(hotelData[,2:32], normalize))

#Checking for any NA value 
sapply(hotelData,function(x) sum(is.na(x)))

#Dropping the 4 NA values in Children column
hotelData <- hotelData[!is.na(hotelData$children), ]
sapply(hotelData,function(x) sum(is.na(x))) #checking again

head(hotelData)

#Feature Engineering
#deleting the variables which have no significance
hotelData <- select(hotelData, -one_of('agent','arrival_date_year','arrival_date_month','arrival_date_week_number',
                                       'arrival_date_day_of_month','country','lead_time','company',
                                       'reserved_room_type','assigned_room_type','required_car_parking_spaces','reservation_status_date','reservation_status'))

dim(hotelData)

#multi-variate analysis of the variables
plot_correlation(na.omit(hotelData), maxcat = 8L)

#Spliting the data into Testing and Training
"30% for testing and 70% for training" 
#seed 234
set.seed (234)
newHotelData <- sort(sample(nrow(hotelData), nrow(hotelData)*0.7))

#Training data
train <- hotelData[newHotelData,]

#Testing data
test <- hotelData[-newHotelData,]

dim(train)
dim(test)

#Creating seperate dataframe for 'IsCancelled' feature which is our target.
train.hotel <- hotelData[newHotelData,2]
test.hotel <- hotelData[-newHotelData,2]

#Model Development (kNN model)
##fit a kNN model with the training dataset
#install.packages("FNN")
library(FNN)

#Find the number of observation
"To find the optimal K value, we find the square root of the total number 
of observations in the training data set"
NROW(train.hotel) 
#the sqrt root of 83570 is 289... k = 289 and K = 290

#When k = 289
knn.289 <- knn(train=train, test=test, cl=train.hotel, k=289)

#ACCURACY for k = 289
Acc.289 <- 100 * sum(test.hotel == knn.289)/NROW(test.hotel)

#Confusion matrix for K = 289
confusionMatrix(table(knn.289 ,test.hotel)) 

#When k = 290
knn.290 <- knn(train=train, test=test, cl=train.hotel, k=290)

#ACCURACY for k = 290
Acc.290 <- 100 * sum(test.hotel == knn.290)/NROW(test.hotel)

#Confusion matrix for K = 289
confusionMatrix(table(knn.290 ,test.hotel))


#SUPPORT VECTOR MACHINE
#install.packages("e1071")
#install.packages("kernlab")

library(e1071)
library(kernlab)

#Changing the target to a factor
hotelDataCat <- hotelData
hotelDataCat$is_canceled <- as.factor(hotelDataCat$is_canceled)

#trctrl <- trainControl(method = "repeatedcv", number = 1, repeats = 1)
#svm.model <- train(hotelDataCat ~., data = train, method = "svmLinear",
#trControl=trctrl,
#preProcess = c("center", "scale"),
#tuneLength = 10)

newData <- data.frame(hotelDataCat, hotelDataCat$is_canceled)
svm.model = svm(is_canceled ~ ., data = newData , kernel = "radial", cost = 10, scale = FALSE)
svm.model

svmPred <- predict(svm.model, data = test)
svmPred

#Confusion matrix for SVM
library(caret)
testCat <- test
testCat$is_canceled <- as.factor(testCat$is_canceled)

confusionMatrix(table(svmPred, is_canceled))

install.packages("MLmetrics")
library(MLmetrics)

#F1 Score
F1_Score(testCat$is_canceled, svmPred, positive = "0")
F1_Score(testCat$is_canceled, svmPred, positive = "1")

length(svmPred)
length(test$is_canceled)


